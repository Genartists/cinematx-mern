import { useEffect, useState } from "react";

function Navbar() {
  const [username, setUsername] = useState(null);

  useEffect(() => {
    // take username from localStorage
    const storedUser = localStorage.getItem("username");
    if (storedUser) setUsername(storedUser);
  }, []);

  function handleLogout() {
    localStorage.removeItem("username");
    setUsername(null);
  }

  return (
    <nav className="flex items-center justify-between px-16 text-[#153a43] h-18">
      <div className="font-extrabold text-2xl cursor-pointer tracking-wide">
        <a href="/Home">Cinematx</a>
        <strong className="text-[#ff7c4d]">.</strong>
      </div>
      <div className="flex items-center gap-4">
        {username ? (
          <>
            <span className="font-medium">Welcome, {username}!</span>
            <button
              onClick={handleLogout}
              className="px-4 py-1 rounded-4xl bg-[#ff7c4d] hover:bg-[#153a43] font-semibold hover:text-white transition"
            >
              Logout
            </button>
          </>
        ) : (
          <>
            <a
              href="/login"
              className="px-4 py-1 rounded-4xl bg-[#ff7c4d] hover:bg-[#153a43] font-semibold hover:text-white transition"
            >
              Login
            </a>
            <a
              href="/register"
              className="px-3 py-1 rounded-4xl bg-[#ff7c4d] hover:bg-[#153a43] font-semibold hover:text-white transition"
            >
              Register
            </a>
          </>
        )}
      </div>
    </nav>
  );
}

export default Navbar;
